return {
	name = "Cloudflare",
	label = _("Cloudflare"),
	resolver_url = "https://cloudflare-dns.com/dns-query",
	bootstrap_dns = "1.1.1.1,1.0.0.1,2606:4700:4700::1111,2606:4700:4700::1001",
	help_link = "https://one.one.one.one/family/",
	help_link_text = "Cloudflare"
}
