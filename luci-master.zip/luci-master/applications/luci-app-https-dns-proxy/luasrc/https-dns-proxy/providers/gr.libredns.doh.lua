return {
	name = "LibreDNS",
	label = _("LibreDNS"),
	resolver_url = "https://doh.libredns.gr/dns-query",
	bootstrap_dns = "116.202.176.26",
	help_link = "https://libredns.gr/",
	help_link_text = "LibreDNS.gr"
}
