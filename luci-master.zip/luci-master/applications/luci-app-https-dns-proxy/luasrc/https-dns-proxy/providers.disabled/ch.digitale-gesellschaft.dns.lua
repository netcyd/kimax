return {
	name = "Digitale-Gesellschaft",
	label = _("Digitale Gesellschaft"),
	resolver_url = "https://dns.digitale-gesellschaft.ch/dns-query",
	bootstrap_dns = "185.95.218.42,185.95.218.43"
}
